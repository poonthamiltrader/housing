<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>
                    document.write(new Date().getFullYear())
                </script> © Hawkeye Digitech.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design & Develop by Hawkeye Digitech
                </div>
            </div>
        </div>
    </div>
</footer>
</div>
<!-- end main content-->

<div id="preloader">
    <div id="status1">
        <div class="spinner-border text-primary avatar-sm" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
</div>

</div>
<!-- END layout-wrapper -->

<!-- JAVASCRIPT -->
<script src="{{ asset('public/assets/js/pages/jquery.min.js') }}"></script>

<script src="{{ asset('public/assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('public/assets/libs/simplebar/simplebar.min.js') }}"></script>
<script src="{{ asset('public/assets/libs/node-waves/waves.min.js') }}"></script>
<script src="{{ asset('public/assets/libs/feather-icons/feather.min.js') }}"></script>
<script src="{{ asset('public/assets/js/pages/plugins/lord-icon-2.1.0.js') }}"></script>
{{-- <script src="{{ asset('public/assets/js/plugins.js') }}"></script> --}}

<!-- apexcharts -->
<script src="{{ asset('public/assets/libs/apexcharts/apexcharts.min.js') }}"></script>

<!-- Vector map-->
<script src="{{ asset('public/assets/libs/jsvectormap/js/jsvectormap.min.js') }}"></script>
<script src="{{ asset('public/assets/libs/jsvectormap/maps/world-merc.js') }}"></script>

<!--Swiper slider js-->
<script src="{{ asset('public/assets/libs/swiper/swiper-bundle.min.js') }}"></script>

<!-- Dashboard init -->
<script src="{{ asset('public/assets/js/pages/dashboard-ecommerce.init.js') }}"></script>
{{-- Common js --}}
<script src="{{ asset('public/assets/js/common.js') }}"></script>
<!--datatable js-->
<script src="{{ asset('public/assets/js/pages/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('public/assets/js/pages/dataTables.bootstrap5.min.js') }}"></script>
{{-- <script src="{{ asset('public/assets/js/pages/dataTables.responsive.min.js') }}"></script> --}}
<script src="{{ asset('public/assets/js/pages/dataTables.buttons.min.js') }}"></script>
<script src="{{ asset('public/assets/js/pages/buttons.html5.min.js') }}"></script>
<script src="{{ asset('public/assets/js/pages/vfs_fonts.js') }}"></script>
<script src="{{ asset('public/assets/js/pages/pdfmake.min.js') }}"></script>
<script src="{{ asset('public/assets/js/pages/jszip.min.js') }}"></script>
{{-- <script src="{{ asset('public/assets/js/pages/datatables.init.js') }}"></script> --}}

<!-- Sweet Alerts js -->
<script src="{{ asset('public/assets/libs/sweetalert2/sweetalert2.min.js') }}"></script>
<script src="{{ asset('/public/assets/js/toastr/toastr.min.js') }}"></script>

<!-- Sweet alert init js-->
<script src="{{ asset('public/assets/js/pages/sweetalerts.init.js') }}"></script>

<!-- profile-setting init js -->
<script src="{{ asset('public/assets/js/pages/profile-setting.init.js') }}"></script>
<!-- App js -->
<script src="{{ asset('public/assets/js/app.js') }}"></script>

</body>

</html>
